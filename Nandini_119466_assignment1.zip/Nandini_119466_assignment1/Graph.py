""" Graph Representation"""
""" Undirected Graph is used for intercity connections"""

from collections import defaultdict
""" Using defaultdict collection class of Python to hold all city nodes and its connections"""
""" a defaultdict will have a default value if that key has not been set yet """

class GermanCity(object):
    """ Undirected Graph Class Representation """

    def __init__(self, connectedCityNodes, isDirectedGraph=False):
        """Initiate Graph, Type of Graph and Connections among Nodes"""
        self._finalGraph = defaultdict(set)
        self._isDirected = isDirectedGraph
        self.add_connections(connectedCityNodes)

    def addEdge(self, sourceNode, destinationNode):
        """ Add connection between one node to another node """
        self._finalGraph[sourceNode].add(destinationNode)
        if not self._isDirected:
            self._finalGraph[destinationNode].add(sourceNode)

    def add_connections(self, connectedCityNodes):
        """ Add connections among all nodes to graph """
        for sourceNode, destinationNode in connectedCityNodes:
            self.addEdge(sourceNode, destinationNode)

    def removeNode(self, node):
        """ Remove node and its related connections"""
        for n, connectedEdge in self._graph.iteritems():
            try:
                connectedEdge.remove(node)
            except KeyError:
                pass
        try:
            del self._finalGraph[node]
        except KeyError:
            pass

    def is_connected(self, sourceNode, destinationNode):
        """ Is source node directly connected to destination node """
        return sourceNode in self._finalGraph and destinationNode in self._finalGraph[sourceNode]

    def find_path(self, sourceNode, destinationNode, path=[]):
        """ Find path between source node and destination node """
        path = path + [sourceNode]
        if sourceNode == destinationNode:
            return path
        if sourceNode not in self._finalGraph:
            return None
        for node in self._finalGraph[sourceNode]:
            if node not in path:
                new_path = self.find_path(node, destinationNode, path)
                if new_path:
                    return new_path
        return None

    def __str__(self):
        return '{}({})'.format(self.__class__.__name__, dict(self._finalGraph))

connectedCityNodes = [('BERLIN', 'FRANKFURT'), ('FRANKFURT', 'ROSTOCK'), ('FRANKFURT', 'DORTMUND'),('ROSTOCK', 'DORTMUND'), ('HANOVER', 'THURINGIA'), ('THURINGIA', 'ROSTOCK')]
"""graph = GermanCity(connections, directed=True)
print(graph._finalGraph)"""
graph = GermanCity(connectedCityNodes)
print("-----------German Cities and Connections-----------------")
print(graph._finalGraph)
graph.addEdge('THURINGIA', 'DORTMUND')
print("-------------Modified Graph, after new connection has been created between THURINGIA and DORTMUND------------------")
print(graph._finalGraph)
"""graph.remove('BERLIN')
print(graph._finalGraph)"""
graph.addEdge('POTSDAM', 'FRANKFURT')
print("-----------------Modified Graph, after new connection has been created between POTSDAM and FRANKFURT----------------------")
print(graph._finalGraph)
findPath = graph.find_path('POTSDAM', 'HANOVER')
print("---------------------Path between POTSDAM and HANOVER-------------------------------")
print(findPath)